// Request -> Peticion Usuario (req)
// Resource -> Resultado de la Peticion (res)

const inicio = (req, res) => {
    res.render("inicio");
}

// const mio = (req, res) => {
//     res.render("mio");
// }

// Esportaciones de funciones
export{
    inicio
    // mio
}